package cz.timepool.dao;

/**
 *
 * @author Adam Samec <adam.smec@gmail.com>
 */
public interface TimepoolDaoIface extends GenericDao{

}
