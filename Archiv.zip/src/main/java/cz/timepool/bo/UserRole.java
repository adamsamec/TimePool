
package cz.timepool.bo;

/**
 *
 * @author Lukas L.
 */
public enum UserRole {
    ADMIN,REGISTERED, UNREGISTERED;
}
