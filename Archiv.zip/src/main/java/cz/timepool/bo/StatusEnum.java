package cz.timepool.bo;

/**
 *
 * @author Lukas L.
 */
public enum StatusEnum {

    VOLNY , PLNY;
}
