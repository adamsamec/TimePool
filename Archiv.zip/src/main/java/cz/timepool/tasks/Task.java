
package cz.timepool.tasks;

/**
 *
 * @author Lukas L.
 */
public class Task
{
	public void printMe() {
		System.out.println("Everything is ok for now ;)");
	}
}
